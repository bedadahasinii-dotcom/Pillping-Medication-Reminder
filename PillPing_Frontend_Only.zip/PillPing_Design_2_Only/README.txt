PILLPING — FRONTEND-ONLY PATIENT & CAREGIVER DEMO
=================================================

TECHNOLOGIES
------------
- HTML
- CSS
- Vanilla JavaScript
- Browser LocalStorage

No Python, Flask, SQLite, Node.js, npm or database server is used.

FOLDER STRUCTURE
----------------
PillPing_Design_2_Only/
  index.html
  css/
    style.css
  js/
    script.js
  README.txt

HOW TO RUN
----------
1. Extract the project folder.
2. Open the folder in VS Code.
3. Open index.html in Chrome or Edge, OR install the VS Code Live Server
   extension, right-click index.html and choose "Open with Live Server".
4. The website starts in dark mode. Use the top-right button to switch to light mode.

FEATURES
--------
- Navy & Lavender Design 2 only.
- Dark mode by default; light mode toggle.
- Patient dashboard and caregiver dashboard views (role-view demo, not secure login).
- Add medicines with name, dosage/instructions, reminder time, daily or one-time schedule.
- Four example medicine entries for demonstration only.
- Confirm a dose as taken.
- Daily completion percentage.
- Previous day / Today / Next day navigation. Moving to another date does not erase history.
- Dose history retained in browser LocalStorage.
- Missed-dose alert after scheduled time plus 15 minutes, while this page is open.
- Caregiver alert list and mark-as-reviewed action.
- Caregiver follow-up notes.
- Default caregiver phone setting in js/script.js; no repeated number entry by patient.
- Call and SMS links open the device's phone or messaging application.
- Optional browser notifications, subject to browser permission.
- Responsive layout and smooth transitions.

CONFIGURATION
-------------
Open js/script.js and change this line once to the real caregiver contact:
  const CAREGIVER = { name: 'Son · Primary caregiver', phone: '+919000000000' };
Use the international format including country code.

IMPORTANT LIMITATIONS
---------------------
This is a frontend-only demonstration. LocalStorage saves data in the current
browser profile on this device. It does not synchronize between a patient's and
caregiver's separate devices, and the two dashboard views are not secure user
accounts. Anyone using the same browser profile can access the local demo data.

Missed-dose checks and browser notifications work only while the page is open.
A browser notification is not a reliable alarm if the browser or device is off.
Call and SMS buttons open the device's dialer/messaging app; they do not send
messages automatically. Real remote caregiver alerts, secure login and cross-
device synchronization require a backend or an external service.

Medicine names and schedules shown are sample demonstration data, not medical
advice. Use only schedules confirmed by the patient's doctor or pharmacist.
A missed-dose alert means the dose was not confirmed; it does not prove that the
medicine was physically not taken.

DATA RESET
----------
To clear this demo's stored data, open browser developer tools > Application >
Local Storage and remove the key "pillping_frontend_data_v3". This removes local
browser demo records only.
