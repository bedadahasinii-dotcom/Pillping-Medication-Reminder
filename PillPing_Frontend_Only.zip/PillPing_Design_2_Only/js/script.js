/* PillPing frontend-only demo: HTML + CSS + JavaScript + LocalStorage. */
const CAREGIVER = { name: 'Son · Primary caregiver', phone: '+919000000000' }; // Replace once with the real number.
const GRACE_MINUTES = 15;
const DATA_KEY = 'pillping_frontend_data_v3';
const THEME_KEY = 'pillping_navy_theme_v3';
const $ = (id) => document.getElementById(id);
const todayISO = () => new Date().toISOString().slice(0, 10);
const starterMedicines = [
  { id: 'sample-1', name: 'Amlodipine', dosage: 'As prescribed', time: '08:00', frequency: 'daily', note: '' },
  { id: 'sample-2', name: 'Metformin', dosage: 'As prescribed', time: '08:30', frequency: 'daily', note: '' },
  { id: 'sample-3', name: 'Atorvastatin', dosage: 'As prescribed', time: '20:00', frequency: 'daily', note: '' },
  { id: 'sample-4', name: 'Calcium + Vitamin D', dosage: 'As prescribed', time: '21:00', frequency: 'daily', note: '' }
];
function loadData() {
  try {
    const saved = JSON.parse(localStorage.getItem(DATA_KEY));
    if (saved && Array.isArray(saved.medicines)) return { medicines: saved.medicines, doses: saved.doses || {}, alerts: saved.alerts || {}, notes: saved.notes || [] };
  } catch (error) { console.warn('Saved PillPing data could not be read. Starting a clean demo.', error); }
  return { medicines: starterMedicines.map(m => ({ ...m })), doses: {}, alerts: {}, notes: [] };
}
let data = loadData();
let selectedDate = todayISO();
function saveData() { localStorage.setItem(DATA_KEY, JSON.stringify(data)); }
function escapeHTML(value) { return String(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch])); }
function prettyDate(iso) { return new Date(`${iso}T12:00:00`).toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }); }
function prettyTime(time) { const [h, m] = time.split(':').map(Number); return new Date(2000, 0, 1, h, m).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); }
function doseKey(medicineId) { return `${selectedDate}_${medicineId}`; }
function getDose(medicineId, date = selectedDate) { return data.doses[`${date}_${medicineId}`] || null; }
function scheduledForDate(medicine, date) { return medicine.frequency === 'daily' || medicine.createdDate === date; }
function getScheduled(date) { return data.medicines.filter(m => scheduledForDate(m, date)).sort((a, b) => a.time.localeCompare(b.time)); }
function notifyToast(message) { const toast = $('toast'); toast.textContent = message; toast.classList.add('show'); window.clearTimeout(notifyToast.timer); notifyToast.timer = window.setTimeout(() => toast.classList.remove('show'), 2800); }
function browserNotify(title, body) {
  if ('Notification' in window && Notification.permission === 'granted') new Notification(title, { body });
}
function updateContactLinks(message = 'Please check on your family member.') {
  $('caregiverName').textContent = CAREGIVER.name;
  $('caregiverPhoneDisplay').textContent = `${CAREGIVER.phone} · Configured contact`;
  $('callLink').href = `tel:${CAREGIVER.phone}`;
  $('smsLink').href = `sms:${CAREGIVER.phone}?body=${encodeURIComponent(message)}`;
}
function getAlertForDose(date, medicineId) { return data.alerts[`${date}_${medicineId}`] || null; }
function createMissedAlert(medicine, date) {
  const key = `${date}_${medicine.id}`;
  if (data.doses[key]?.status === 'taken' || data.alerts[key]) return false;
  const alert = { id: key, date, medicineId: medicine.id, medicineName: medicine.name, dosage: medicine.dosage, time: medicine.time, message: `PillPing alert: Your father has not confirmed taking ${medicine.name}, scheduled for ${prettyTime(medicine.time)}. Please check on him.`, createdAt: new Date().toISOString(), reviewed: false };
  data.alerts[key] = alert;
  saveData();
  browserNotify('PillPing missed-dose alert', alert.message);
  return true;
}
function checkMissedDoses() {
  const now = new Date();
  let created = 0;
  data.medicines.forEach(medicine => {
    if (!scheduledForDate(medicine, todayISO())) return;
    const key = `${todayISO()}_${medicine.id}`;
    if (data.doses[key]?.status === 'taken' || data.alerts[key]) return;
    const [hour, minute] = medicine.time.split(':').map(Number);
    const due = new Date(); due.setHours(hour, minute + GRACE_MINUTES, 0, 0);
    if (now >= due) { if (createMissedAlert(medicine, todayISO())) created++; }
  });
  if (created) notifyToast(`${created} missed-dose alert${created > 1 ? 's' : ''} added to caregiver dashboard.`);
  renderAll();
}
function renderMedicineList() {
  const list = $('medicineList');
  const medicines = getScheduled(selectedDate);
  if (!medicines.length) { list.innerHTML = '<div class="empty-state">No medicines scheduled for this date. Add a medicine above.</div>'; return; }
  list.innerHTML = medicines.map(m => {
    const dose = getDose(m.id);
    const alert = getAlertForDose(selectedDate, m.id);
    const status = dose?.status === 'taken' ? 'Taken and confirmed' : alert ? 'Not confirmed · caregiver alerted' : 'Waiting for confirmation';
    const statusClass = dose?.status === 'taken' ? 'done' : alert ? 'missed' : '';
    const action = dose?.status === 'taken' ? '<button class="small-button" disabled>Confirmed ✓</button>' : `<button class="primary-button" data-action="taken" data-id="${escapeHTML(m.id)}">I have taken this</button>`;
    return `<article class="medicine" id="medicine-${escapeHTML(m.id)}"><div><div class="med-title">${escapeHTML(m.name)}</div><div class="med-meta">${escapeHTML(m.dosage)} · ${m.frequency === 'daily' ? 'Every day' : 'One-time'}${m.note ? ` · ${escapeHTML(m.note)}` : ''}</div><div class="status ${statusClass}">${status}</div></div><div><div class="med-time">${prettyTime(m.time)}</div><div class="med-actions">${action}<button class="small-button" data-action="remove" data-id="${escapeHTML(m.id)}">Remove</button></div></div></article>`;
  }).join('');
}
function renderProgress() {
  const meds = getScheduled(selectedDate);
  const taken = meds.filter(m => getDose(m.id)?.status === 'taken').length;
  const percent = meds.length ? Math.round(taken / meds.length * 100) : 0;
  $('heroTaken').textContent = `${taken}/${meds.length}`;
  $('medicineCount').textContent = `${meds.length} MEDICINES`;
  $('progressText').textContent = `${percent}%`;
  $('progressBar').style.width = `${percent}%`;
}
function renderAlerts() {
  const alerts = Object.values(data.alerts).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const open = alerts.filter(a => !a.reviewed);
  $('navAlertCount').textContent = open.length;
  $('patientAlertBadge').textContent = `${open.length} OPEN`;
  $('caregiverOpenCount').textContent = open.length;
  const patientBox = $('patientAlertList');
  patientBox.innerHTML = open.length ? open.slice(0, 4).map(a => `<div class="alert-item open"><strong>${escapeHTML(a.medicineName)} was not confirmed</strong><p>${escapeHTML(a.message)}</p><span class="alert-meta">${prettyDate(a.date)} · ${prettyTime(a.time)}</span></div>`).join('') : '<div class="empty-state compact">No open missed-dose alerts.</div>';
  const caregiverBox = $('caregiverAlertList');
  caregiverBox.innerHTML = alerts.length ? alerts.map(a => `<div class="alert-item ${a.reviewed ? 'reviewed' : 'open'}"><strong>${escapeHTML(a.medicineName)} · ${a.reviewed ? 'Reviewed' : 'Needs follow-up'}</strong><p>${escapeHTML(a.message)}</p><span class="alert-meta">${prettyDate(a.date)} · ${prettyTime(a.time)} · Alert created ${new Date(a.createdAt).toLocaleString()}</span><div class="alert-actions"><a class="secondary-link" href="tel:${CAREGIVER.phone}">Call patient</a><a class="secondary-link" href="sms:${CAREGIVER.phone}?body=${encodeURIComponent(a.message)}">Prepare SMS</a>${a.reviewed ? '' : `<button class="small-button" data-review="${escapeHTML(a.id)}">Mark reviewed</button>`}</div></div>`).join('') : '<div class="empty-state">No missed-dose alerts yet. Alerts appear after a scheduled dose and the grace period.</div>';
}
function renderHistory() {
  const rows = Object.entries(data.doses).map(([key, dose]) => {
    const split = key.indexOf('_'); const date = key.slice(0, split); const id = key.slice(split + 1);
    const medicine = data.medicines.find(m => String(m.id) === String(id));
    return { date, dose, medicine };
  }).filter(row => row.medicine).sort((a, b) => b.date.localeCompare(a.date) || b.dose.updatedAt.localeCompare(a.dose.updatedAt)).slice(0, 30);
  $('historyTable').innerHTML = rows.length ? rows.map(row => `<tr><td>${prettyDate(row.date)}</td><td>${escapeHTML(row.medicine.name)}</td><td>${prettyTime(row.medicine.time)}</td><td><span class="pill ${row.dose.status === 'taken' ? 'taken' : 'missed'}">${row.dose.status === 'taken' ? 'Taken' : 'Missed'}</span></td><td>${new Date(row.dose.updatedAt).toLocaleString()}</td></tr>`).join('') : '<tr><td colspan="5" class="table-empty">No dose history yet.</td></tr>';
}
function renderNotes() {
  const notes = [...data.notes].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  $('careNotesList').innerHTML = notes.length ? notes.map(note => `<div class="note-item"><strong>Care follow-up</strong><p>${escapeHTML(note.text)}</p><span class="alert-meta">${new Date(note.createdAt).toLocaleString()}</span></div>`).join('') : '<div class="empty-state compact">No care notes yet.</div>';
}
function renderCaregiverSummary() {
  const meds = getScheduled(todayISO());
  const taken = meds.filter(m => getDose(m.id, todayISO())?.status === 'taken').length;
  const missed = meds.filter(m => getAlertForDose(todayISO(), m.id)).length;
  $('summaryScheduled').textContent = meds.length;
  $('summaryConfirmed').textContent = taken;
  $('summaryMissed').textContent = missed;
  $('summaryPercent').textContent = `${meds.length ? Math.round(taken / meds.length * 100) : 0}%`;
}
function renderDate() {
  $('selectedDateTitle').textContent = selectedDate === todayISO() ? "Today's schedule" : selectedDate > todayISO() ? 'Upcoming schedule' : 'Past schedule';
  $('selectedDateText').textContent = prettyDate(selectedDate);
  $('headerDate').textContent = prettyDate(todayISO());
}
function renderAll() {
  renderDate(); renderMedicineList(); renderProgress(); renderAlerts(); renderHistory(); renderNotes(); renderCaregiverSummary();
  updateContactLinks();
}
$('medicineForm').addEventListener('submit', event => {
  event.preventDefault();
  const name = $('medicineName').value.trim(); const dosage = $('dosage').value.trim(); const time = $('medicineTime').value;
  if (!name || !dosage || !time) { notifyToast('Please complete the medicine name, dosage and time.'); return; }
  const medicine = { id: `med-${Date.now()}`, name, dosage, time, frequency: $('frequency').value, note: $('medicineNote').value.trim(), createdDate: selectedDate };
  data.medicines.push(medicine); saveData(); event.target.reset(); $('frequency').value = 'daily'; renderAll(); notifyToast('Medicine added to your schedule.');
});
$('medicineList').addEventListener('click', event => {
  const button = event.target.closest('button[data-action]'); if (!button) return;
  const id = button.dataset.id; const medicine = data.medicines.find(m => String(m.id) === String(id)); if (!medicine) return;
  if (button.dataset.action === 'taken') {
    const key = `${selectedDate}_${medicine.id}`;
    data.doses[key] = { status: 'taken', updatedAt: new Date().toISOString() };
    if (data.alerts[key]) data.alerts[key].reviewed = true;
    saveData(); renderAll(); const card = $(`medicine-${CSS.escape(String(id))}`); if (card) card.classList.add('just-done'); notifyToast(`${medicine.name} marked as taken.`);
  }
  if (button.dataset.action === 'remove') {
    if (!confirm(`Remove ${medicine.name} from the medicine plan? Existing history will be kept.`)) return;
    data.medicines = data.medicines.filter(m => String(m.id) !== String(id)); saveData(); renderAll(); notifyToast('Medicine removed from the active schedule.');
  }
});
$('previousDayBtn').addEventListener('click', () => { const d = new Date(`${selectedDate}T12:00:00`); d.setDate(d.getDate() - 1); selectedDate = d.toISOString().slice(0, 10); renderAll(); });
$('nextDayBtn').addEventListener('click', () => { const d = new Date(`${selectedDate}T12:00:00`); d.setDate(d.getDate() + 1); selectedDate = d.toISOString().slice(0, 10); renderAll(); notifyToast('Showing the next day. Previous dose history has been preserved.'); });
$('todayBtn').addEventListener('click', () => { selectedDate = todayISO(); renderAll(); });
document.querySelectorAll('.view-tab').forEach(tab => tab.addEventListener('click', () => {
  document.querySelectorAll('.view-tab').forEach(t => t.classList.toggle('active', t === tab));
  document.querySelectorAll('.view-panel').forEach(panel => panel.classList.toggle('active', panel.id === tab.dataset.view));
}));
$('caregiverAlertList').addEventListener('click', event => {
  const button = event.target.closest('[data-review]'); if (!button) return;
  const alert = data.alerts[button.dataset.review]; if (alert) { alert.reviewed = true; alert.reviewedAt = new Date().toISOString(); saveData(); renderAll(); notifyToast('Alert marked as reviewed.'); }
});
$('noteForm').addEventListener('submit', event => {
  event.preventDefault(); const text = $('careNote').value.trim(); if (!text) { notifyToast('Write a short care note first.'); return; }
  data.notes.push({ id: `note-${Date.now()}`, text, createdAt: new Date().toISOString() }); saveData(); $('careNote').value = ''; renderNotes(); notifyToast('Care note saved on this browser.');
});
$('enableNotificationsBtn').addEventListener('click', async () => {
  if (!('Notification' in window)) { notifyToast('This browser does not support desktop notifications.'); return; }
  const permission = await Notification.requestPermission();
  notifyToast(permission === 'granted' ? 'Browser notifications enabled.' : 'Notification permission was not granted.');
});
const savedTheme = localStorage.getItem(THEME_KEY); document.documentElement.dataset.theme = savedTheme === 'light' ? 'light' : 'dark';
function updateThemeButton() { $('themeToggle').textContent = document.documentElement.dataset.theme === 'dark' ? '☀ Light mode' : '☾ Dark mode'; }
$('themeToggle').addEventListener('click', () => { const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = next; localStorage.setItem(THEME_KEY, next); updateThemeButton(); });
updateThemeButton();
// If another PillPing tab in this same browser changes LocalStorage, refresh this tab too.
window.addEventListener('storage', event => { if (event.key === DATA_KEY) { data = loadData(); renderAll(); } });
renderAll(); checkMissedDoses(); window.setInterval(checkMissedDoses, 30000);
